import React from 'react';

export default function Statistics() {
  return <>
        <div className="col-xl-3 col-sm-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="row">
                  <div className="col-9">
                    <div className="d-flex align-items-center align-self-start">
                      <h3 className="mb-0">$85.34</h3>
                      <p className="text-success ml-2 mb-0 font-weight-medium">+11%</p>
                    </div>
                  </div>
                  <div className="col-3">
                    <div className="icon icon-box-success">
                      <span className="mdi mdi-arrow-top-right icon-item text-success"></span>
                    </div>
                  </div>
                </div>
                <h6 className="text-muted font-weight-normal">Current Balance</h6>
              </div>
            </div>
        </div>
        <div className="col-xl-3 col-sm-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="row">
                  <div className="col-9">
                    <div className="d-flex align-items-center align-self-start">
                      <h3 className="mb-0">$12.34</h3>
                      <p className="text-success ml-2 mb-0 font-weight-medium">+3.5%</p>
                    </div>
                  </div>
                  <div className="col-3">
                    <div className="icon icon-box-success ">
                      <span className="mdi mdi-arrow-top-right icon-item text-success"></span>
                    </div>
                  </div>
                </div>
                <h6 className="text-muted font-weight-normal">Weekly Income</h6>
              </div>
            </div>
        </div>
          
        <div className="col-xl-3 col-sm-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="row">
                  <div className="col-9">
                    <div className="d-flex align-items-center align-self-start">
                      <h3 className="mb-0">$12.34</h3>
                      <p className="text-danger ml-2 mb-0 font-weight-medium">-2.4%</p>
                    </div>
                  </div>
                  <div className="col-3">
                    <div className="icon icon-box-danger">
                      <span className="mdi mdi-arrow-bottom-left icon-item text-danger"></span>
                    </div>
                  </div>
                </div>
                <h6 className="text-muted font-weight-normal">Fund Transferred</h6>
              </div>
            </div>
        </div>
        <div className="col-xl-3 col-sm-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="row">
                  <div className="col-9">
                    <div className="d-flex align-items-center align-self-start">
                      <h3 className="mb-0">$9.53</h3>
                      <p className="text-success ml-2 mb-0 font-weight-medium">+3.5%</p>
                    </div>
                  </div>
                  <div className="col-3">
                    <div className="icon icon-box-danger ">
                      <span className="mdi mdi-arrow-bottom-left icon-item text-danger"></span>
                    </div>
                  </div>
                </div>
                <h6 className="text-muted font-weight-normal">Accumulated Charges</h6>
              </div>
            </div>
        </div>
  </>;
}

const Tansactions = [
    {
        Id: '200003372737744737239',
        BeneficiaryAccount: '02312121221',
        Amount: '14,500',
        DateofTransaction: '04 Dec 2019',
        Paystatus: 'Approved'
    },
    {
        Id: '100013372737744737239',
        BeneficiaryAccount: '02312121221',
        Amount: '14,500',
        DateofTransaction: '04 Dec 2019',
        Paystatus: 'Pending'
    },
    {
        Id: '000023372737744737239',
        BeneficiaryAccount: '02312121221',
        Amount: '14,500',
        DateofTransaction: '04 Dec 2019',
        Paystatus: 'Declined'
    },
];

export default Tansactions;